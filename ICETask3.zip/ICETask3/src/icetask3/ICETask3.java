/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetask3;

/**
 *
 * @author ndoum
 */
import java.util.Scanner;
import java.util.Random;

public class ICETask3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        String inputData = input.nextLine();
        String answer = null;
        System.out.println(isValid(inputData, answer));

        Random random = new Random();
        int i = 1;
        int num = random.nextInt(100);
        while (i >= 1) {
            oddSqrSum(num);
            i++;
        }
        System.out.println(oddSqrSum(num));

        System.out.println("Please enter the first number");
        int firstNum = input.nextInt();
        System.out.println("Please enter the second number");
        int secondNum = input.nextInt();
        System.out.println("Your divisor is "+ commonDivisor(firstNum, secondNum));
    }

    public static String isValid(String inputData, String answer) {
        boolean openBrackets = inputData.contains("(") && inputData.contains(")");
        boolean sqrBrackets = inputData.contains("[") && inputData.contains("]");
        boolean curlyBrackets = inputData.contains("{") && inputData.contains("}");
        if (openBrackets || sqrBrackets && curlyBrackets) {
            answer = "valid";
        } else {
            answer = "invalid";
        }
        return answer;
    }

    public static int oddSqrSum(int num) {
        int power = 0;
        int sum = 0;
        boolean odd = num % 2 == 1;
        if (odd) {
            power = (int) Math.exp(num);
            sum = +power;
        }
        return sum;
    }

    public static double commonDivisor(int firstNum, int secondNum) {
        int divisor = 1;
        String answer = "NO";
        while (answer.equals("NO")) {
            if (divisor == 1) {
                boolean sum1 = firstNum % divisor == 0;
                boolean sum2 = firstNum % divisor == 0;
            }
            divisor++;
            
        }
        int num = divisor;
        return num;
    }
}
